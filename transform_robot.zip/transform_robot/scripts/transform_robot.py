#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
import math
import tf
from tf import TransformListener

#----------------------------------------------------------------------------------------------------------------------------------------
currentOdom=Odometry()

def findDistanceBetweenAngles(a, b):
	result = 0
	difference = b - a
	if difference > math.pi:
		difference = math.fmod(difference, math.pi)
		result = difference - math.pi
	elif(difference < -math.pi):
		result = difference + (2*math.pi)
	else:
		result = difference
	return result

def displaceAngle(a1, a2):
	a2 = a2 % (2.0*math.pi)
	if a2 > math.pi:
		a2 = (a2 % math.pi) - math.pi
	return findDistanceBetweenAngles(-a1,a2)

# Turn the robot to a specific orientation value
def turnTo(theta, pub):
    # The orientation before we start turning
    thetaStart = tf.transformations.euler_from_quaternion( [currentOdom.pose.pose.orientation.x, currentOdom.pose.pose.orientation.y, currentOdom.pose.pose.orientation.z, currentOdom.pose.pose.orientation.w] )[2]
    # Get the angle between the robot's current orientation and the target orientation
    thetaDist = findDistanceBetweenAngles(theta, thetaStart)
    # Make a rate
    rate = rospy.Rate(30)
    # Create the Twist msg
    vel = Twist()
    vel.linear.x = 0
    vel.angular.z = 0.785 # Speed could be a parameter
    # Make a threshold to check for stopping the robot
    threshold = 0.35
    # While the robot is not at the specified orientation (or within a small threshold)
    while abs(thetaDist) > threshold and not rospy.is_shutdown():
        # Drive the robot
        pub.publish(vel)
        # Get the robot's current orientation
        thetaNow = tf.transformations.euler_from_quaternion( [currentOdom.pose.pose.orientation.x, currentOdom.pose.pose.orientation.y, currentOdom.pose.pose.orientation.z, currentOdom.pose.pose.orientation.w] )[2]
        # Update the angle between
        thetaDist = findDistanceBetweenAngles(thetaNow, theta)
        print('thetaNow: %s thetaDist: %s' % (thetaNow, thetaDist))
        # Sleep
        rate.sleep()
    # Stop robot by publishing 1 more Twist with 0 speed
    vel.angular.z=0
    pub.publish(vel)


# Drive the robot based on distance
def driveDist(dist, pub):
    # Make a rate to publish messages
    rate = rospy.Rate(30)
    # Get the robot's current odometry info
    tempOdom = currentOdom
    # Initial distance from starting position is 0
    tempDist = 0
    # Create the Twist msg
    vel = Twist()
    vel.linear.x = 0.33 # Speed could be a parameter
    vel.angular.z = 0
    # While we haven't moved the specified distance
    while tempDist < dist and not rospy.is_shutdown():
        # Drive the robot
        pub.publish(vel)
        # Update distance
        tempDist = math.sqrt( math.pow(tempOdom.pose.pose.position.x - currentOdom.pose.pose.position.x,2) + math.pow(tempOdom.pose.pose.position.y - currentOdom.pose.pose.position.y,2) )
        # Sleep
        rate.sleep()
    # Stop robot by publishing 1 more Twist with 0 speed
    vel.linear.x = 0
    pub.publish(vel)

#-----------------------------------------------------------------------------------------------------------------------------------------

def callbackodom(data):
	global currentOdom
	currentOdom=data

def run():
	global currentOdom
	rospy.init_node('pub_map_odom',anonymous=True)
	pub=rospy.Publisher('/cmd_vel',Twist,queue_size=10)
	br=tf.TransformBroadcaster()
	br.sendTransform((2.5,0.5,0.0),tf.transformations.quaternion_from_euler(0,0,0.785),rospy.Time.now(),"odom","map")
	lis=TransformListener()
	rospy.Subscriber('/odom',Odometry,callbackodom)
	rate = rospy.Rate(10)
	while not rospy.is_shutdown():
		lis.waitForTransform("map","odom",rospy.Time(),rospy.Duration(4.0))
		(trans,rot)=lis.lookupTransform("map","odom",rospy.Time(0))
		turnto(rot[2])
		dist=math.sqrt((2.5-trans[0])**2 + (0.5-trans[1])**2)
		driveDistance(dist,pub)
		rate.sleep()
		rospy.spin()


if __name__=='__main__':
	try:
		run()
	except rospy.ROSInterruptException:
		pass