#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
import math

currentOdom=Odometry()

def turnTo(theta,pub):
	global currentOdom
	t=Twist()
	t.angular.x=.2
	while not rospy.is_shutdown():
		x=currentOdom.twist.twist.angular.x
		theta=theta+x
		while x<theta:
			pub.publish(t)
			x=currentOdom.twist.twist.angular.x
	t.angular.x=0
	pub.publish(t)

def driveDistance(dist,pub):
	global currentOdom
	t=Twist()
	t.linear.x=.2
	while not rospy.is_shutdown():
		x=currentOdom.pose.pose.position.x
		y=currentOdom.pose.pose.position.y
		d=math.sqrt((x**2)+(y**2))
		dist=dist+d
		while d<dist:
			pub.publish(t)
			x=currentOdom.pose.pose.position.x
			y=currentOdom.pose.pose.position.y
			d=math.sqrt((x**2)+(y**2))
	t.linear.x=0
	pub.publish(t)

def callbackodom(data):
	global currentOdom
	currentOdom=data
	print(data)

def run():
	rospy.init_node('drive_robot',anonymous=True)
	rospy.Subscriber('/odom',Odometry,callbackodom)
	pub=rospy.Publisher('/cmd_vel',Twist,queue_size=10)
	driveDistance(.2,pub)
	toTurn(.2,pub)
	rospy.spin()

if __name__=='__main__':
	try:
		run()
	except rospy.ROSInterruptException:
		pass